const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection pool
const pool = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: '',
  database: 'jablab',
  waitForConnections: true,
  connectionLimit: 10,
});

// ─── AUTH ENDPOINTS ───────────────────────────────────────────────────────────

// POST /api/register
app.post('/api/register', async (req, res) => {
  try {
    const { first_name, last_name, email, password } = req.body;
    if (!first_name || !last_name || !email || !password)
      return res.status(400).json({ error: 'Tutti i campi sono obbligatori' });

    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.execute(
      'INSERT INTO users (first_name, last_name, email, password_hash) VALUES (?, ?, ?, ?)',
      [first_name, last_name, email, hash]
    );
    res.json({ success: true, userId: result.insertId });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'Email già registrata' });
    res.status(500).json({ error: 'Errore del server' });
  }
});

// POST /api/login
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Credenziali non valide' });

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: 'Credenziali non valide' });

    res.json({
      success: true,
      user: { id: user.id, first_name: user.first_name, last_name: user.last_name, email: user.email },
    });
  } catch (err) {
    res.status(500).json({ error: 'Errore del server' });
  }
});

// ─── FAVORITES ENDPOINTS ──────────────────────────────────────────────────────

// GET /api/favorites/:userId
app.get('/api/favorites/:userId', async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT fighter_id FROM favorites WHERE user_id = ?',
      [req.params.userId]
    );
    res.json(rows.map((r) => r.fighter_id));
  } catch (err) {
    res.status(500).json({ error: 'Errore del server' });
  }
});

// POST /api/favorites
app.post('/api/favorites', async (req, res) => {
  try {
    const { user_id, fighter_id } = req.body;
    await pool.execute(
      'INSERT IGNORE INTO favorites (user_id, fighter_id) VALUES (?, ?)',
      [user_id, fighter_id]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Errore del server' });
  }
});

// DELETE /api/favorites
app.delete('/api/favorites', async (req, res) => {
  try {
    const { user_id, fighter_id } = req.body;
    await pool.execute(
      'DELETE FROM favorites WHERE user_id = ? AND fighter_id = ?',
      [user_id, fighter_id]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Errore del server' });
  }
});

// ─── BOXING API PROXY ─────────────────────────────────────────────────────────
// Proxy per evitare CORS con l'API esterna di boxe

const axios = require('axios');
const BOXING_API_KEY = 'YOUR_API_KEY_HERE'; // Inserisci la tua API key
const BOXING_API_BASE = 'https://v1.boxing.api-sports.io';

app.get('/api/fighters', async (req, res) => {
  try {
    const { search } = req.query;
    const response = await axios.get(`${BOXING_API_BASE}/boxers`, {
      headers: { 'x-apisports-key': BOXING_API_KEY },
      params: { search },
    });
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Errore API esterna' });
  }
});

app.get('/api/fighter/:id', async (req, res) => {
  try {
    const response = await axios.get(`${BOXING_API_BASE}/boxers`, {
      headers: { 'x-apisports-key': BOXING_API_KEY },
      params: { id: req.params.id },
    });
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Errore API esterna' });
  }
});

// Gestione errori
app.use((req, res) => res.status(404).json({ error: 'Pagina non trovata' }));
app.use((err, req, res, next) => res.status(500).json({ error: 'Errore del server' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`JAB LAB backend running on port ${PORT}`));
