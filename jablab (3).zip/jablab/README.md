# 🥊 JAB LAB – Boxing Analytics Platform

Piattaforma web React per l'analisi delle statistiche di boxe.

## Struttura del progetto

```
jablab/
├── backend/
│   └── server.js          # Express API server (Node.js)
├── database/
│   └── jablab.sql          # Schema e dati del database MySQL
├── public/
│   └── index.html          # HTML principale
├── src/
│   ├── components/
│   │   ├── Navbar.js       # Barra di navigazione
│   │   └── FighterCard.js  # Card pugile
│   ├── context/
│   │   ├── AuthContext.js      # Gestione autenticazione
│   │   └── FavoritesContext.js # Gestione preferiti
│   ├── hooks/
│   │   └── useBoxingAPI.js # Hook per API boxe
│   ├── pages/
│   │   ├── Home.js         # Homepage
│   │   ├── Login.js        # Pagina login
│   │   ├── Register.js     # Pagina registrazione
│   │   ├── Dashboard.js    # Dashboard principale
│   │   ├── FighterDetail.js# Dettaglio pugile + grafici
│   │   └── Favorites.js    # Pugili preferiti
│   ├── App.js              # Routing principale
│   ├── index.js            # Entry point React
│   └── index.css           # Stili globali
└── package.json
```

## 🚀 Installazione e avvio

### 1. Frontend (React)

```bash
# Dalla cartella jablab/
npm install
npm start
```

Il sito sarà disponibile su: **http://localhost:3000**

### 2. Backend (Node.js + Express)

```bash
# Dalla cartella jablab/backend/
npm init -y
npm install express mysql2 bcryptjs cors axios
node server.js
```

Il backend sarà su: **http://localhost:5000**

### 3. Database (MySQL)

1. Apri **phpMyAdmin** (o MySQL Workbench)
2. Crea un database chiamato `jablab`
3. Importa il file `database/jablab.sql`

---

## 🔑 API Key Boxe

Il progetto usa l'API **API-Sports Boxing** (`https://v1.boxing.api-sports.io`).

1. Registrati su [api-sports.io](https://api-sports.io)
2. Ottieni la tua API key gratuita
3. Inseriscila in `src/hooks/useBoxingAPI.js`:

```js
const API_KEY = 'LA_TUA_API_KEY_QUI';
```

> **Nota**: Senza API key il progetto funziona ugualmente con **dati mock** (pugili famosi precaricati come Canelo Alvarez, Tyson Fury, ecc.)

---

## 👤 Account Demo

Senza backend attivo, puoi accedere con:
- **Email**: `demo@jablab.com`
- **Password**: `demo123`

---

## 📱 Pagine disponibili

| Route | Descrizione |
|-------|-------------|
| `/` | Homepage con introduzione |
| `/login` | Pagina di accesso |
| `/register` | Pagina di registrazione |
| `/dashboard` | Dashboard con ricerca pugili |
| `/fighter/:id` | Dettaglio pugile con grafici |
| `/favorites` | Lista pugili preferiti |

---

## 🗄️ Database

Il database locale gestisce solo **utenti e preferiti**.
I dati sportivi vengono recuperati tramite API esterne.

**Tabelle:**
- `users` – id, first_name, last_name, email, password_hash, created_at
- `favorites` – id, user_id, fighter_id

**Relazione:** 1 utente → N preferiti (1:N)

---

## 🛠️ Tecnologie usate

| Layer | Tecnologia |
|-------|-----------|
| Frontend | React 18, React Router v6 |
| Grafici | Recharts |
| Backend | Node.js, Express |
| Database | MySQL / phpMyAdmin |
| Stili | CSS custom con variabili |
| API Dati | API-Sports Boxing API |

---

*Progetto realizzato da Papa, Giovannini, Manku – Classe 5DIA*
