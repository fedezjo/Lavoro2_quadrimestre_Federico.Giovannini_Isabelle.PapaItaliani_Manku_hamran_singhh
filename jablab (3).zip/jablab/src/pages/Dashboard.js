import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import FighterCard from '../components/FighterCard';
import { useBoxingAPI } from '../hooks/useBoxingAPI';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { searchFighters, getTrendingFighters, loading } = useBoxingAPI();
  const [query, setQuery] = useState('');
  const [fighters, setFighters] = useState([]);
  const [trending, setTrending] = useState([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => { if (!user) navigate('/login'); }, [user, navigate]);
  useEffect(() => { getTrendingFighters().then(setTrending); }, [getTrendingFighters]);

  useEffect(() => {
    if (!query.trim()) { setFighters([]); setSearching(false); return; }
    setSearching(true);
    const t = setTimeout(async () => {
      const r = await searchFighters(query);
      setFighters(r); setSearching(false);
    }, 400);
    return () => clearTimeout(t);
  }, [query, searchFighters]);

  const displayFighters = query.trim() ? fighters : trending;
  const title = query.trim() ? `Risultati per "${query}"` : 'Giocatori di tendenza 🔥';

  const handleLogout = () => { logout(); navigate('/'); };

  return (
    <div style={{ minHeight:'100vh', position:'relative', overflow:'hidden' }}>
      {/* BG */}
      <img src="/images/bg.png" alt="bg" style={{ position:'fixed', inset:0, width:'100%', height:'100%', objectFit:'cover', zIndex:0 }} />
      <div style={{ position:'fixed', inset:0, zIndex:1, background:'rgba(220,232,255,0.55)' }} />

      {/* NAVBAR */}
      <nav style={{
        position:'fixed', top:0, left:0, right:0, zIndex:100, height:64,
        background:'rgba(190,215,255,0.88)', backdropFilter:'blur(14px)', WebkitBackdropFilter:'blur(14px)',
        borderBottom:'2px solid rgba(26,60,255,0.20)',
        display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px',
        boxShadow:'0 2px 16px rgba(26,60,255,0.08)'
      }}>
        <Link to="/dashboard" style={{ fontFamily:'var(--font-display)', fontSize:'2.1rem', letterSpacing:'2px', color:'var(--primary)', textDecoration:'none' }}>
          Jab Lab
        </Link>
        <div style={{ display:'flex', gap:12 }}>
          <Link to="/favorites" className="btn btn-primary" style={{ padding:'9px 22px', fontSize:'0.95rem' }}>
            ⭐ Preferiti
          </Link>
          <button onClick={handleLogout} className="btn btn-danger" style={{ padding:'9px 22px', fontSize:'0.95rem' }}>
            Esci
          </button>
        </div>
      </nav>

      {/* CONTENT */}
      <div style={{ position:'relative', zIndex:2, paddingTop:80, padding:'80px 32px 60px' }}>

        {/* Search bar centrata come nel Figma */}
        <div style={{ display:'flex', justifyContent:'center', marginBottom:36 }}>
          <div className="search-bar" style={{ maxWidth:500, width:'100%', background:'rgba(255,255,255,0.85)' }}>
            <span style={{ fontSize:'1.1rem' }}>🔍</span>
            <input
              type="text"
              placeholder="cerca pugile..."
              value={query}
              onChange={e => setQuery(e.target.value)}
            />
            {query && (
              <button onClick={() => setQuery('')} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', fontSize:'1.1rem' }}>✕</button>
            )}
          </div>
        </div>

        {/* Fighters grid */}
        {(loading || searching) ? (
          <div className="spinner" />
        ) : displayFighters.length === 0 ? (
          <div style={{ textAlign:'center', padding:'60px 24px', fontFamily:'var(--font-condensed)', color:'var(--text-muted)', fontSize:'1.1rem', background:'rgba(255,255,255,0.5)', borderRadius:16, maxWidth:400, margin:'0 auto' }}>
            {query.trim() ? '😕 Nessun pugile trovato' : '⏳ Caricamento...'}
          </div>
        ) : (
          <>
            <div style={{
              fontFamily:'var(--font-condensed)', fontSize:'1rem', fontWeight:700,
              color:'var(--text)', marginBottom:16, textAlign:'center',
              letterSpacing:'1px', textTransform:'uppercase',
              display:'flex', alignItems:'center', justifyContent:'center', gap:8
            }}>
              {title}
            </div>
            <div style={{
              display:'grid',
              gridTemplateColumns:'repeat(auto-fill, minmax(190px, 1fr))',
              gap:18
            }}>
              {displayFighters.map((fighter, i) => (
                <div key={fighter.id} style={{ animationDelay:`${i*0.05}s` }}>
                  <FighterCard fighter={fighter} />
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* BOXING badge */}
      <div style={{ position:'fixed', bottom:68, right:28, zIndex:10, background:'rgba(255,255,255,0.80)', borderRadius:12, padding:'8px 14px', border:'2px solid rgba(0,0,0,0.12)', display:'flex', flexDirection:'column', alignItems:'center', gap:2 }}>
        <span style={{ fontSize:'1.4rem' }}>🥊</span>
        <span style={{ fontFamily:'var(--font-display)', fontSize:'0.8rem', letterSpacing:'2px', color:'#222', lineHeight:1 }}>BOXING</span>
      </div>
      <div style={{ position:'fixed', bottom:22, right:28, zIndex:10, display:'flex', gap:10 }}>
        <span style={{ fontSize:'2rem', cursor:'pointer' }}>🇮🇹</span>
        <span style={{ fontSize:'2rem', cursor:'pointer' }}>🇬🇧</span>
      </div>
    </div>
  );
}
